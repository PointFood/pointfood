package pe.edu.upc.extraservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtraServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtraServiceApplication.class, args);
	}

}
