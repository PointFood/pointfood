package pe.edu.upc.extraservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExtraServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
